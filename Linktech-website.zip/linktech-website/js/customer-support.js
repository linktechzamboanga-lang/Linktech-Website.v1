
// GOOGLE CLIENT ID

const GOOGLE_CLIENT_ID =
"495855477306-9rdg89fh3g5mtolu8th08ltojor8lkkr.apps.googleusercontent.com";



// GOOGLE APPS SCRIPT API URL

const API_URL =
"https://script.google.com/macros/s/AKfycbySupjniFyZfxWCMCjTNYa6uQjjKT6gQ0Q2Fs6ELd29ghjzJA9Ld6CU78HUjrSxRMsqhg/exec
";

// CURRENT USER

let currentUser = null;

// ==========================================
// START SYSTEM
// ==========================================


window.onload=function(){


initializeGoogle();


};


// ==========================================
// GOOGLE LOGIN
// ==========================================


function initializeGoogle(){



google.accounts.id.initialize({


client_id: GOOGLE_CLIENT_ID,


callback: handleGoogleLogin


});

google.accounts.id.renderButton(

document.getElementById(
"googleLoginButton"
),


{

theme:"outline",

size:"large",

width:300

}


);



}


// ==========================================
// RECEIVE GOOGLE LOGIN
// ==========================================


function handleGoogleLogin(response){

let token =
response.credential;
verifyGoogle(token);



}


// ==========================================
// VERIFY GOOGLE USER
// ==========================================


function verifyGoogle(token){

fetch(API_URL,{

method:"POST",

body:JSON.stringify({


type:"googleLogin",


token:token


})


})


.then(res=>res.json())

.then(data=>{



if(data.success){



currentUser=data.user;



localStorage.setItem(

"linktechUser",

JSON.stringify(data.user)

);



showUser();



}

else{


alert(
"Google Login Failed"
);


}



});


}







// ==========================================
// SHOW USER
// ==========================================


function showUser(){



document.getElementById(
"googleLoginButton"
).style.display="none";



document.getElementById(
"userProfile"
).style.display="block";



document.getElementById(
"dashboard"
).style.display="block";




document.getElementById(
"userName"
).innerHTML=
currentUser.name;



document.getElementById(
"userEmail"
).innerHTML=
currentUser.email;




document.getElementById(
"userImage"
).src=
currentUser.picture;



// auto fill


document.getElementById(
"name"
).value=
currentUser.name;



document.getElementById(
"email"
).value=
currentUser.email;



loadTimeline();


}








// ==========================================
// LOGOUT
// ==========================================


function logoutUser(){



localStorage.removeItem(
"linktechUser"
);



location.reload();


}









// ==========================================
// DASHBOARD BUTTONS
// ==========================================



function showConcern(){


hideSections();


document.getElementById(
"concernSection"
).style.display="block";


}




function showTimeline(){


hideSections();


document.getElementById(
"timelineSection"
).style.display="block";


loadTimeline();


}




function showRequests(){


hideSections();


document.getElementById(
"requestSection"
).style.display="block";


loadRequests();


}





function hideSections(){



document.getElementById(
"concernSection"
).style.display="none";


document.getElementById(
"timelineSection"
).style.display="none";


document.getElementById(
"requestSection"
).style.display="none";


}









// ==========================================
// SUBMIT CONCERN
// ==========================================


function submitConcern(){


if(!currentUser){

alert(
"Please Sign in with Google first."
);

return;

}



let data={


type:"concern",


name:
document.getElementById("name").value,


email:
currentUser.email,


address:
document.getElementById("address").value,


contact:
document.getElementById("contact").value,


problem:
document.getElementById("problem").value



};




fetch(API_URL,{


method:"POST",


body:JSON.stringify(data)



})


.then(res=>res.json())


.then(result=>{



document.getElementById(
"concernMessage"
).innerHTML=
result.message;



});


}









// ==========================================
// LOAD TIMELINE
// ==========================================


function loadTimeline(){



fetch(

API_URL+
"?type=timeline"

)



.then(res=>res.json())


.then(posts=>{



let html="";



posts.forEach(post=>{



html+=`


<div class="timeline-card">



<img src="${post.image}"
width="250">



<h3>
${post.title}
</h3>



<p>
${post.caption}
</p>



<small>
${post.date}
</small>



<br>


<button onclick="likePost('${post.id}')">

❤️ ${post.likes}

</button>



<button onclick="openComments('${post.id}')">

💬 Comment

</button>



</div>



`;



});




document.getElementById(
"timeline"
).innerHTML=html;



});



}









// ==========================================
// LIKE POST
// ==========================================


function likePost(id){



fetch(API_URL,{


method:"POST",


body:JSON.stringify({


type:"like",


id:id,


email:currentUser.email



})


})


.then(()=>loadTimeline());


}









// ==========================================
// COMMENT
// ==========================================


function sendComment(){



let text=
document.getElementById(
"commentText"
).value;



fetch(API_URL,{


method:"POST",


body:JSON.stringify({


type:"comment",


email:currentUser.email,


name:currentUser.name,


comment:text



})


})

.then(()=>{


alert(
"Comment posted"
);


});



}









// ==========================================
// LOAD MY REQUESTS
// ==========================================


function loadRequests(){



fetch(

API_URL+
"?type=myRequests&email="
+
currentUser.email


)


.then(res=>res.json())


.then(data=>{



let html="";



data.forEach(item=>{



html+=`


<div>


<h4>
${item.problem}
</h4>


<p>
Status:
${item.status}
</p>


<small>
${item.timestamp}
</small>


</div>


`;



});



document.getElementById(
"myRequests"
).innerHTML=html;



});



}









// ==========================================
// ADMIN LOGIN
// ==========================================


function loginAdmin(){



fetch(API_URL,{


method:"POST",


body:JSON.stringify({


type:"adminLogin",


email:
adminEmail.value,


password:
adminPassword.value



})


})


.then(res=>res.json())


.then(data=>{


if(data.success){



adminPanel.style.display="block";


alert(
"Admin Login Success"
);



}else{


alert(
"Invalid Login"
);


}



});



}